package tasks.utils;

/**
 * Created by grigo on 11/8/16.
 */
public enum TaskEventType {
    StartingTaskExecution, TaskExecutionCompleted, TaskExecutionCancelled
}
