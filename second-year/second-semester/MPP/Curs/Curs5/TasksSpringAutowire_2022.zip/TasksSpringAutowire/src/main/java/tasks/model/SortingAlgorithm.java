package tasks.model;

/**
 * Created by grigo on 11/14/16.
 */
public enum SortingAlgorithm {
    QUICK_SORT, BUBBLE_SORT, SELECTION_SORT;
}
