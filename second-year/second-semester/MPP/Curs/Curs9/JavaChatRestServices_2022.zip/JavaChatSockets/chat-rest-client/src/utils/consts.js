/**
 * Created by grigo on 5/19/17.
 */
export const CHAT_USERS_BASE_URL='http://localhost:8080/chat/users';