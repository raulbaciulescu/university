package chat.network.objectprotocol;


public class OkResponse implements Response{
}
