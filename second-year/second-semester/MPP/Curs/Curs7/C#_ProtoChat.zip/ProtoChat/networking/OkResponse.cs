using System;
namespace chat.network.protocol
{

	///
	/// <summary> * Created by IntelliJ IDEA.
	/// * User: grigo
	/// * Date: Mar 18, 2009
	/// * Time: 4:29:54 PM </summary>
	/// 
	[Serializable]
    public class OkResponse : Response
	{
	}

}