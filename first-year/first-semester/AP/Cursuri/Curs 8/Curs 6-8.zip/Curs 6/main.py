from Domain.vot_validator import VotValidator
from Repository.repository import Repository
from Service.vot_service import VotService
from UserInterface.console import Console


def main():
    vot_validator = VotValidator()
    vot_repository1 = Repository()
    vot_repository2 = Repository()

    vot_service = VotService(vot_repository1, vot_validator)

    console = Console(vot_service)
    console.run_console()

print([] is None)
main()