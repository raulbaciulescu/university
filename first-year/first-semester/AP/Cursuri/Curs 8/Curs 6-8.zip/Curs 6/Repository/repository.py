class Repository:

    def __init__(self):
        self.__next_id = 0
        self.__storage = {}

    def read(self, id_entity=None): # posibil si find_by_id + get_all
        if id_entity is None:
            return list(self.__storage.values())

        if id_entity in self.__storage:
            return self.__storage[id_entity]

        return None

    def upsert(self, entity): # posibil si insert + update
        if entity.id_entity is None: # TODO: pus breakpoint pe vechea varianta: if self.read(entity.id_entity) is None
            entity.id_entity = self.__next_id
            self.__next_id += 1
        self.__storage[entity.id_entity] = entity

    def delete(self, id_entity):
        if self.read(id_entity) is None:
            raise KeyError(f'Entitatea cu ID-ul {id_entity} nu exista!')

        del self.__storage[id_entity]