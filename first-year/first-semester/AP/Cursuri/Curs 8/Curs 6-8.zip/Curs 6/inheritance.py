class Animal:

    def __init__(self, name):
        self.name = name
        self.something = 43

    def sound(self):
        return 'Generic animal sound'

class Dog(Animal):
    def __init__(self, name):
        super().__init__(name)

    def sound(self):
        return 'woof woof ' + str(self.something)

class Cat(Animal):
    def __init__(self, name):
        super().__init__(name)

    def sound(self):
        return 'meow meow'

def f(animals: [Animal]):
    for a in animals:
        print(a.sound())

a = Animal('asdf')
d = Dog('fsd')
c = Cat('ffsdsd')
print(a.__something)
f([a, d, c])
