from Tests.add_logic_tests import test_add_rationals


def run_all_tests():
    test_add_rationals()