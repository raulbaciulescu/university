package util;

public class Constants {
    public static Integer NUMBER_OF_POLYNOMIALS = 10;
    public static Integer MAX_DEGREE = 1000;
    public static Integer MAX_MONO = 50;
    public static Integer p;
    public static Integer SIZE_OF_QUEUE = 20;

    public static Integer numberOfProducers, numberOfConsumers;
}
