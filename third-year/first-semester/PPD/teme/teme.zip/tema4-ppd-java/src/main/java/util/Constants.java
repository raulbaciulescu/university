package util;

public class Constants {
    public static Integer numberOfPolynomials = 1;
    public static Integer maxDegree = 10000;
    public static Integer maxMono = 100;
    public static Integer p;
    public static boolean runFlag;
}
