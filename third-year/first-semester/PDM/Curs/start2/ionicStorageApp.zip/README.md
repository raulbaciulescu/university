Change log

01 Storage

- Ionic storage, https://capacitorjs.com/docs/apis/storage
