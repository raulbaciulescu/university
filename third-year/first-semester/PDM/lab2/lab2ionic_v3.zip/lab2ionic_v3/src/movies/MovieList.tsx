import {
    createAnimation,
    IonButton,
    IonButtons,
    IonContent,
    IonFab,
    IonFabButton,
    IonHeader, IonIcon, IonInfiniteScroll, IonInfiniteScrollContent,
    IonList,
    IonLoading,
    IonPage, IonSearchbar, IonSelect, IonSelectOption,
    IonTitle,
    IonToolbar
} from '@ionic/react';
import React, {useContext, useEffect, useState} from "react";
import {RouteComponentProps} from "react-router";
import {add} from "ionicons/icons";
import {getLogger} from "../core";
import {MovieContext} from "./MovieProvider";
import Movie from "../movies/Movie";
// import {useNetwork} from "../network/useNetwork";
import {AuthContext} from "../auth";
import {usePhotos} from "../photo/usePhotos";

const log = getLogger('MovieList');
const MovieList: React.FC<RouteComponentProps> = ({history}) => {
    const {movies, fetching, fetchingError, fetchMovies, resetLogout} = useContext(MovieContext);
    const {photos, takePhoto, deletePhoto} = usePhotos();
    const [searchMovies, setSearchMovies] = useState<string>('');
    const {isAuthenticated, logout} = useContext(AuthContext);
    const [languages, setLanguages] = useState<string[]>(['romana', 'english', 'default', 'franc', 'spaniola']);
    const [filter, setFilter] = useState<string>("default");
    const [disableInfiniteScroll, setDisableInfiniteScroll] = useState<boolean>(false);
    // const {networkStatus} = useNetwork();

    const handleLogout = () => {
        if (isAuthenticated) {
            resetLogout?.();
            logout?.();
        }
    }

    // useEffect(() => {
    //     log(filter)
    //     fetchMovies?.(filter);
    // }, [filter])

    function searchNext($event: CustomEvent<void>) {
        fetchMovies?.(filter ? filter : "");
        ($event.target as HTMLIonInfiniteScrollElement).complete();
    }

    function onSearchChanged(language: string) {
        log('search ')
        if (language === "")
            language = "default"
        setSearchMovies(language);
        fetchMovies?.(language);
    }

    useEffect(simpleAnimationJS, []);

    function simpleAnimationJS() {
        const el = document.querySelector('.square-a');
        if (el) {
            const animation = createAnimation()
                .addElement(el)
                .duration(5000)
                .direction('alternate')
                .iterations(Infinity)
                .keyframes([
                    { offset: 0, transform: 'scale(3)', opacity: '1' },
                    { offset: 0.5, transform: 'scale(1.5)', opacity: '1' },
                    {
                        offset: 1, transform: 'scale(0.5)', opacity: '0.2'
                    }
                ]);
            animation.play();
        }
    }

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <div className="square-a">
                        <p>Movies</p>
                    </div>
                    {/*<div>Network status is {JSON.stringify(networkStatus)}</div>*/}
                    <IonButtons slot="end">
                        <IonButton routerLink='/' routerDirection='root' onClick={handleLogout}>
                            Logout
                        </IonButton>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonSearchbar
                    value={searchMovies}
                    debounce={1000}
                    onIonChange={e => onSearchChanged(e.detail.value!)}>
                </IonSearchbar>
                <IonSelect value={filter} placeholder="Select language" onIonChange={e => setFilter(e.detail.value)}>
                    {languages.map(language => <IonSelectOption key={language}
                                                                value={language}>{language}</IonSelectOption>)}
                </IonSelect>
                <IonLoading isOpen={fetching} message="Fetching items"/>
                {movies && (
                    <IonList>
                        {movies.map(({
                                         _id, name, language,
                                         manager, year, userId, photoPath, lat, lng}) => {
                                let photoView = "";
                                for (let photo of photos) {
                                    if (photo.filepath === photoPath) {
                                        photoView = photo.webviewPath ? photo.webviewPath : "";
                                    }
                                }

                                return <Movie key={_id}
                                              _id={_id}
                                              name={name}
                                              language={language}
                                              manager={manager}
                                              year={year}
                                              userId={userId}
                                              onEdit={id => history.push(`/items/${id}`)}
                                              photoPath={photoView}
                                              lat={lat}
                                              lng={lng}/>
                            }
                        )}
                    </IonList>
                )}
                {fetchingError && (
                    <div>{fetchingError.message || 'Failed to fetch items'}</div>
                )}
                <IonInfiniteScroll threshold="100px" disabled={disableInfiniteScroll}
                                   onIonInfinite={(e: CustomEvent<void>) => {
                                       searchNext(e)
                                   }}>
                    <IonInfiniteScrollContent
                        loadingText="Loading more good books...">
                    </IonInfiniteScrollContent>
                </IonInfiniteScroll>
                <IonFab vertical="bottom" horizontal="end" slot="fixed">
                    <IonFabButton onClick={() => history.push('/items/add')}>
                        <IonIcon icon={add}/>
                    </IonFabButton>
                </IonFab>
            </IonContent>
        </IonPage>
    );
};

export default MovieList;
