import React from 'react';
import {
    IonCard, IonCardContent,
    IonCardHeader,
    IonCardSubtitle, IonCardTitle,
    IonContent,
    IonHeader,
    IonImg,
    IonItem,
    IonLabel,
    IonTitle
} from '@ionic/react';
import {MovieProps} from './MovieProps';

interface MoviePropsExt extends MovieProps {
    onEdit: (_id?: string) => void;
}

const Movie: React.FC<MoviePropsExt> = ({_id, name,
                                            language, manager,
                                            year, photoPath,
                                            lat, lng, onEdit}) => {
    return (
        <IonItem onClick={() => onEdit(_id)}>
            <IonCard>
                <img alt="NO PHOTO" src={photoPath} />
                <IonCardHeader>
                    <IonCardTitle>{name}</IonCardTitle>
                    <IonCardSubtitle>{language}</IonCardSubtitle>
                </IonCardHeader>
                <IonCardContent>
                    Movie with id {_id}, name {name}, language {language}, manager {manager}, year {year}, lat: {lat}, lng: {lng}
                </IonCardContent>
            </IonCard>
        </IonItem>
    );
};

export default Movie;
