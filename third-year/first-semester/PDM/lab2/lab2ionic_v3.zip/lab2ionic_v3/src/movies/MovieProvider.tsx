import React, {useCallback, useContext, useEffect, useReducer, useState} from 'react';
import PropTypes from 'prop-types';
import {getLogger} from '../core';
import {MovieProps} from './MovieProps';
import {createMovie, getMovies, getMoviesFiltered, getMoviesPaginated, newWebSocket, updateMovie} from './movieApi';
import {AuthContext} from '../auth';
import {save} from "ionicons/icons";
import { Preferences } from '@capacitor/preferences';
// import {useNetwork} from "../network/useNetwork";
import movie from "./Movie";

const log = getLogger('MovieProvider');

type SaveMovieFn = (item: MovieProps) => Promise<any>;
type FetchFN = () => void;
type FetchFilterFN = (language: string) => void;

export interface MoviesState {
    movies?: MovieProps[],
    fetching: boolean,
    fetchingError?: Error | null,
    saving: boolean,
    resetLogout?: FetchFN,
    fetchMovies?: FetchFilterFN,
    fetchFilteredMovies?: FetchFilterFN,
    savingError?: Error | null,
    saveMovie?: SaveMovieFn,
}

interface ActionProps {
    type: string,
    payload?: any,
}

const initialState: MoviesState = {
    fetching: false,
    saving: false,
};

const FETCH_ITEMS_STARTED = 'FETCH_ITEMS_STARTED';
const FETCH_ITEMS_SUCCEEDED = 'FETCH_ITEMS_SUCCEEDED';
const FETCH_ITEMS_FAILED = 'FETCH_ITEMS_FAILED';
const SAVE_ITEM_STARTED = 'SAVE_ITEM_STARTED';
const SAVE_ITEM_SUCCEEDED = 'SAVE_ITEM_SUCCEEDED';
const SAVE_ITEM_FAILED = 'SAVE_ITEM_FAILED';
const PAGE_SIZE = 10;

const reducer: (state: MoviesState, action: ActionProps) => MoviesState =
    (state, {type, payload}) => {
        switch (type) {
            case FETCH_ITEMS_STARTED:
                return {...state, fetching: true, fetchingError: null};
            case FETCH_ITEMS_SUCCEEDED:
                return {...state, movies: payload.items, fetching: false};
            case FETCH_ITEMS_FAILED:
                return {...state, fetchingError: payload.error, fetching: false};
            case SAVE_ITEM_STARTED:
                return {...state, savingError: null, saving: true};
            case SAVE_ITEM_SUCCEEDED:
                const movies = [...(state.movies || [])];
                const item = payload.item;
                const index = movies.findIndex(it => it._id === item._id);
                if (index === -1) {
                    movies.splice(0, 0, item);
                } else {
                    movies[index] = item;
                }
                return {...state, movies, saving: false};
            case SAVE_ITEM_FAILED:
                return {...state, savingError: payload.error, saving: false};
            default:
                return state;
        }
    };


export const MovieContext = React.createContext<MoviesState>(initialState);

interface ItemProviderProps {
    children: PropTypes.ReactNodeLike,
}

export const MovieProvider: React.FC<ItemProviderProps> = ({children}) => {
    const [pageNumber, setPageNumber] = useState(0);
    const [lastLanguage, setLastLanguage] = useState("default");
    // const {Storage} = Plugins;
    const {token} = useContext(AuthContext);
    const [state, dispatch] = useReducer(reducer, initialState);
    const {movies, fetching, fetchingError, saving, savingError} = state;
    const saveMovie = useCallback<SaveMovieFn>(saveItemCallback, [token]);
    const value = {movies, fetching, fetchingError, saving, savingError, saveMovie, fetchMovies};
    // const { networkStatus } = useNetwork();

    // useEffect(() => {
    //     const onUseEffect = async () => {
    //         const res = await Storage.get({key: 'movies'});
    //         if (!res.value) {
    //             fetchMovies("default");
    //         } else {
    //            getItemsFromStorage();
    //         }
    //     }
    //     onUseEffect().then();
    // }, [])

    useEffect(() => {
        fetchMovies("default");
    }, [])

    // useEffect(() => {
    //     if (networkStatus.connected) {
    //         saveItemsFromStorage().then();
    //     }
    //
    //     async function saveItemsFromStorage() {
    //         const res = await Storage.get({ key: 'temporary-movies' });
    //         if (res.value) {
    //             const temporaryMovies = JSON.parse(res.value);
    //             log('saveItemsFromStorage' + JSON.stringify(temporaryMovies))
    //             temporaryMovies.forEach(function(movie: MovieProps) {
    //                 saveItemCallback(movie)
    //             });
    //
    //             await Storage.remove({ key: 'temporary-movies' });
    //         }
    //     }
    // }, [networkStatus.connected])

    useEffect(wsEffect, [token]);
    log('returns ' + pageNumber);

    function getItemsFromStorage() {
        getMoviesFromStorage().then();
        async function getMoviesFromStorage() {
            try {
                dispatch({type: FETCH_ITEMS_STARTED});
                const res = await Preferences.get({key: 'movies'});
                if (res.value) {
                    const items = JSON.parse(res.value);
                    log(items)
                    dispatch({type: FETCH_ITEMS_SUCCEEDED, payload: {items}});
                }
            } catch (error) {
                log('fetchItems failed');
                dispatch({type: FETCH_ITEMS_FAILED, payload: {error}});
            }
        }
    }

    async function saveMovieInStorage(editedMovie: MovieProps) {
        const res = await Preferences.get({ key: 'temporary-movies' });
        if (res.value) {
            let temporaryMovies = JSON.parse(res.value);
            temporaryMovies.push(editedMovie)
            await Preferences.set({
                key: 'temporary-movies',
                value: JSON.stringify(temporaryMovies)
            });
            log('saveMovieInStorage ' + JSON.stringify(temporaryMovies))
        }
        else {
            await Preferences.set({
                key: 'temporary-movies',
                value: JSON.stringify([editedMovie])
            });
        }
    }

    async function saveItemCallback(item: MovieProps) {
        // if (!networkStatus.connected) {
        //         log('saveItemCallback not connected')
        //     saveMovieInStorage(item).then();
        //     return;
        // }
        try {
            log('saveItem started');
            dispatch({type: SAVE_ITEM_STARTED});
            const resToken = await Preferences.get({key: 'token'});
            let tok =''
            if (resToken.value) {
                tok = resToken.value
            }
            const savedItem = await (item._id ? updateMovie(tok, item) : createMovie(tok, item));
            console.log('saveItem   ', savedItem)
            log('saveItem succeeded');
            dispatch({type: SAVE_ITEM_SUCCEEDED, payload: {item: savedItem}});
        } catch (error) {
            log('saveItem failed');
            dispatch({type: SAVE_ITEM_FAILED, payload: {error}});
        }
    }

    function wsEffect() {
        let canceled = false;
        log('wsEffect - connecting');
        let closeWebSocket: () => void;
        if (token?.trim()) {
            closeWebSocket = newWebSocket(token, message => {
                if (canceled) {
                    return;
                }
                const {type, payload: item} = message;
                log(`ws message, item ${type}`);
                if (type === 'created' || type === 'updated') {
                    dispatch({type: SAVE_ITEM_SUCCEEDED, payload: {item}});
                }
            });
        }
        return () => {
            log('wsEffect - disconnecting');
            canceled = true;
            closeWebSocket?.();
        }
    }

    function fetchFilteredMovies(language: string) {
        log('fetchFilteredMovies movies ' + language)
        let canceled = false;
        fetchItems().then();
        return () => {
            canceled = true;
        }

        async function fetchItems() {
            log('fetchFilteredMovies')
            const resToken = await Preferences.get({key: 'token'});
            if (!resToken.value) {
                return;
            }
            try {
                log('fetchFilteredMovies started paginated');
                dispatch({type: FETCH_ITEMS_STARTED});

                if (language != lastLanguage) {
                    setPageNumber(0);
                    log('set page number', pageNumber)
                    await Preferences.remove({key: 'movies'});
                }
                setLastLanguage(language);
                let tok = "";
                const resToken = await Preferences.get({key: 'token'});
                if (resToken.value) {
                    tok = resToken.value
                }
                const newItems = await getMoviesFiltered(tok, language);
                const res = await Preferences.get({key: 'movies'});
                log(newItems)
                let items;
                if (res.value) {
                    const resJSON = JSON.parse(res.value);
                    items = resJSON.concat(newItems);
                } else
                    items = newItems

                log('fetchFilteredMovies succeeded paginated');
                if (!canceled) {
                    dispatch({type: FETCH_ITEMS_SUCCEEDED, payload: {items}});
                    await Preferences.set({key: 'movies', value: JSON.stringify(items)});
                }
            } catch (error) {
                log('fetchFilteredMovies failed paginated');
                dispatch({type: FETCH_ITEMS_FAILED, payload: {error}});
            }
        }
    }

    function fetchMovies(language: string) {
        log('fetchMovies ' + language)
        if (language !== 'default') {
            fetchFilteredMovies(language);
            return;
        }
        let canceled = false;
        fetchItems();
        return () => {
            canceled = true;
        }

        async function fetchItems() {
            const resToken = await Preferences.get({key: 'token'});
            if (!resToken.value) {
                return;
            }
            try {
                log('fetchItems started paginated ', language, lastLanguage);
                dispatch({type: FETCH_ITEMS_STARTED});

                if (language != lastLanguage) {
                    setPageNumber(0);
                    log('set page number', pageNumber)
                    await Preferences.remove({key: 'movies'});
                }
                setLastLanguage("default");
                let tok = "";
                const resToken = await Preferences.get({key: 'token'});
                if (resToken.value) {
                    tok = resToken.value
                }

                const newItems = await getMoviesPaginated(tok, pageNumber);
                const res = await Preferences.get({key: 'movies'});

                let items = [];
                if (res.value) {
                    const storageItems = JSON.parse(res.value);
                    //items = storageItems.concat(newItems);
                    items = newItems
                } else
                    items = newItems
               // setPageNumber(pageNumber + PAGE_SIZE)
                log('page ' + pageNumber)
                log('fetchItems succeeded paginated');
                if (!canceled) {
                    dispatch({type: FETCH_ITEMS_SUCCEEDED, payload: {items}});
                    log('mov ' + JSON.stringify(items))
                    await Preferences.set({key: 'movies', value: JSON.stringify(items)});
                }
            } catch (error) {
                log('fetchItems failed paginated');
                dispatch({type: FETCH_ITEMS_FAILED, payload: {error}});
            }
        }
    }

    return (
        <MovieContext.Provider value={value}>
            {children}
        </MovieContext.Provider>
    );
};