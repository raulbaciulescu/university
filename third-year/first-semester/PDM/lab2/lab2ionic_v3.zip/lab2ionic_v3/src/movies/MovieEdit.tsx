import React, {useContext, useEffect, useRef, useState} from 'react';
import {
    IonButton,
    IonButtons, IonCardContent,
    IonContent, IonFab, IonFabButton,
    IonHeader, IonIcon, IonImg,
    IonInput, IonItem, IonLabel,
    IonLoading, IonModal,
    IonPage, IonText,
    IonTitle,
    IonToolbar
} from '@ionic/react';
import { createAnimation, Animation } from "@ionic/core";
import {getLogger} from '../core';
import {MovieContext} from './MovieProvider';
import {RouteComponentProps} from 'react-router';
import {MovieProps} from './MovieProps';
// import {useNetwork} from "../network/useNetwork";
import { Preferences } from '@capacitor/preferences';
import {camera} from "ionicons/icons";
import {MyPhoto, usePhotos} from "../photo/usePhotos";
import MyMap from "../map/MyMap";

const log = getLogger('MovieEdit');

interface MovieEditProps extends RouteComponentProps<{
    id?: string;
}> {
}

const MovieEdit: React.FC<MovieEditProps> = ({history, match}) => {
    // const { networkStatus } = useNetwork();
    const {movies, saving, savingError, saveMovie} = useContext(MovieContext);
    const [name, setName] = useState('');
    const [language, setLanguage] = useState('');
    const [manager, setManager] = useState('');
    const [year, setYear] = useState('');
    const [movie, setMovie] = useState<MovieProps>();
    const [photoToDelete, setPhotoToDelete] = useState<MyPhoto>();
    const [photoPath, setPhotoPath] = useState('');
    const [photoFile, setPhotoFile] = useState('');
    const [offlineText, setOfflineText] = useState("");
    const {photos, takePhoto, deletePhoto} = usePhotos();
    const [lat, setLat] = useState(47.29341652941491);
    const [lng, setLng] = useState(24.15388570663447);

    useEffect(() => {
        const routeId = match.params.id || '';
        const m = movies?.find(mv => mv._id == routeId);
        setMovie(m);

        if (m) {
            let photoView = "";
            getPhotoView(m.photoPath).then((data) => {
                photoView = data
                console.log('ss ', data)
            })
            setName(m.name);
            setLanguage(m.language);
            setManager(m.manager);
            setYear(m.year);
            setPhotoPath(photoView);
            setPhotoFile(m.photoPath);
            setLat(m.lat);
            setLng(m.lng);
        }
    }, [match.params.id]);

    const getPhotoView = async (photoPath: string) => {
        const res = await Preferences.get({key: 'photos'});
        let photoView = "";

        if (res.value) {
           let photosFromStorage : MyPhoto[] = JSON.parse(res.value);
            log(photosFromStorage)

            for (let photo of photosFromStorage) {
                if (photo.filepath === photoPath) {
                    photoView = photo.webviewPath ? photo.webviewPath : "";
                    setPhotoPath(photoView)
                }
            }
        }
        return photoView;
    }

    const handleSave = () => {
        const mov: MovieProps = {
            'photoPath': photoFile,
            '_id': movie?._id,
            'name': name,
            'manager': manager,
            'year': year,
            'language': language,
            'userId': '',
            'lat': lat,
            'lng': lng
        };
        const editedMovie = movie ? mov  : mov;
        setMovie(editedMovie);
        saveMovie?.(editedMovie);
        // if (!networkStatus.connected) {
        //     log('save movie in storage')
        //     setOfflineText("Your items are saved only locally");
        // }
    };

    const setMapPosition = (e: any) => {
        log('map position')
        console.log(e.latitude)
        console.log(e.longitude)
        setLat(e.latitude);
        setLng(e.longitude);
    }

    function mapLog(source: string) {
        return (e: any) => console.log(source, e.latLng.lat(), e.latLng.lng());
    }

    const [showModal, setShowModal] = useState(false);

    const enterAnimation = (baseEl: any) => {
        const backdropAnimation = createAnimation()
            .addElement(baseEl.querySelector("ion-backdrop")!)
            .fromTo("opacity", "0.01", "var(--backdrop-opacity)");

        const wrapperAnimation = createAnimation()
            .addElement(baseEl.querySelector(".modal-wrapper")!)
            .keyframes([
                { offset: 0, opacity: "0", transform: "scale(0)" },
                { offset: 1, opacity: "0.99", transform: "scale(1)" },
            ]);

        return createAnimation()
            .addElement(baseEl)
            .easing("ease-out")
            .duration(500)
            .addAnimation([backdropAnimation, wrapperAnimation]);
    };

    const leaveAnimation = (baseEl: any) => {
        return enterAnimation(baseEl).direction("reverse");
    };

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Edit</IonTitle>
                    {/*<div>Network status is {JSON.stringify(networkStatus)}</div>*/}
                    <IonButtons slot="end">
                        <IonButton onClick={handleSave}>
                            Save
                        </IonButton>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonItem>
                    <IonLabel>Name:</IonLabel>
                    <IonInput value={name} onIonChange={e => setName(e.detail.value || '')}/>
                </IonItem>
                <IonItem>
                    <IonLabel>Language:</IonLabel>
                    <IonInput value={language} onIonChange={e => setLanguage(e.detail.value || '')}/>
                </IonItem>
                <IonItem>
                    <IonLabel>Manager:</IonLabel>
                    <IonInput value={manager} onIonChange={e => setManager(e.detail.value || '')}/>
                </IonItem>
                <IonItem>
                    <IonLabel>Year:</IonLabel>
                    <IonInput value={year} onIonChange={e => setYear(e.detail.value || '')}/>
                </IonItem>
                <IonItem>
                    <IonText>{lat}</IonText>
                </IonItem>
                <IonItem>
                    <IonText>{lng}</IonText>
                </IonItem>
                <IonItem>
                    <IonImg style={{width: "300px", height: "300px", margin: "0 auto"}} alt={"NO PHOTO"}
                            onClick={() => {
                                setPhotoToDelete(photos?.find(vd => vd.webviewPath === photoPath))
                            }}
                            src={photoPath}
                    />
                </IonItem>
                <IonItem>
                    <MyMap lat={lat} lng={lng} onMapClick={setMapPosition} onMarkerClick={() => {}}/>
                </IonItem>
                    <IonCardContent>
                        <IonModal
                            isOpen={showModal}
                            enterAnimation={enterAnimation}
                            leaveAnimation={leaveAnimation}

                        ><div slot='center'>
                            <IonText>This is a modal!!</IonText>
                        </div>
                            <IonButton onClick={() => setShowModal(false)}>Close Image</IonButton>
                        </IonModal>
                        <IonButton onClick={() => setShowModal(true)}>open</IonButton>
                    </IonCardContent>
                <IonFab horizontal="end">
                    <IonFabButton size="small" color="danger"
                                  onClick={() => {
                                      const photoTaken = takePhoto();
                                      photoTaken.then((data) => {
                                          console.log(data)
                                          let filepath = data.filepath;
                                          setPhotoFile(filepath)
                                          setPhotoPath(data.webviewPath!);
                                      });
                                  }}>
                        <IonIcon icon={camera}/>
                    </IonFabButton>
                </IonFab>
                <IonLoading isOpen={saving}/>
                {savingError && (
                    <div>{savingError.message || 'Failed to save item'}</div>
                )}
                {
                    offlineText
                }
            </IonContent>
        </IonPage>
    );
};

export default MovieEdit;
