import axios from 'axios';
import {authConfig, baseUrl, getLogger, withLogs} from '../core';
import {MovieProps} from './MovieProps';

const movieUrl = `http://${baseUrl}/api/item`;

export const getMovies: (token: string) => Promise<MovieProps[]> = token => {
    return withLogs(axios.get(movieUrl, authConfig(token)), 'getMovies');
}

export const getMoviesPaginated: (token: string, page: number) => Promise<MovieProps[]> = (token, page) => {
    return withLogs(axios.get(`${movieUrl}/page/${page}`, authConfig(token)), 'getMoviesPaginated');
}

export const getMoviesFilteredPaginated: (token: string, language: string, page: number) => Promise<MovieProps[]> = (token, language, page) => {
    return withLogs(axios.get(`${movieUrl}/${language}/${page}`, authConfig(token)), 'getMoviesFiltered');
}

export const getMoviesFiltered: (token: string, language: string) => Promise<MovieProps[]> = (token, language) => {
    return withLogs(axios.get(`${movieUrl}/${language}/0`, authConfig(token)), 'getMoviesFiltered');
}

export const createMovie: (token: string, item: MovieProps) => Promise<MovieProps[]> = (token, movie) => {
    console.log('createMovie ', movie)
    return withLogs(axios.post(movieUrl, movie, authConfig(token)), 'createMovie');
}

export const updateMovie: (token: string, movie: MovieProps) => Promise<MovieProps[]> = (token, movie) => {
    return withLogs(axios.put(`${movieUrl}/${movie._id}`, movie, authConfig(token)), 'updateMovie');
}

interface MessageData {
    type: string;
    payload: MovieProps;
}

const log = getLogger('ws');

export const newWebSocket = (token: string, onMessage: (data: MessageData) => void) => {
    const ws = new WebSocket(`ws://${baseUrl}`);
    ws.onopen = () => {
        log('web socket onopen');
        ws.send(JSON.stringify({type: 'authorization', payload: {token}}));
    };
    ws.onclose = () => {
        log('web socket onclose');
    };
    ws.onerror = error => {
        log('web socket onerror', error);
    };
    ws.onmessage = messageEvent => {
        log('web socket onmessage');
        onMessage(JSON.parse(messageEvent.data));
    };
    return () => {
        ws.close();
    }
}
