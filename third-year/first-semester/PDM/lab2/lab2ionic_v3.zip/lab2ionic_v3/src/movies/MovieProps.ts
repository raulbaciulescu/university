export interface MovieProps {
  _id?: string;
  name: string;
  language: string;
  manager: string;
  year: string;
  userId?: string;
  lat: number;
  lng: number;
  photoPath: string;
}
