import Router from 'koa-router';
import noteStore from './store';
import {broadcast} from "../utils";

export const router = new Router();
const PAGE_SIZE = 10000;

router.get('/', async (ctx) => {
    const response = ctx.response;
    const userId = ctx.state.user._id;
    response.body = await noteStore.find({userId});
    response.status = 200; // ok
});

router.get('/:id', async (ctx) => {
    console.log('here')
    const userId = ctx.state.user._id;
    const note = await noteStore.findOne({_id: ctx.params.id});
    const response = ctx.response;
    if (note) {
        if (note.userId === userId) {
            response.body = note;
            response.status = 200; // ok
        } else {
            response.status = 403; // forbidden
        }
    } else {
        response.status = 404; // not found
    }
});

router.get('/page/:p', async (ctx) => {
    const response = ctx.response;
    const userId = ctx.state.user._id;
    const page = Number(ctx.params.p);
    const notes = await noteStore.find({userId});
    // const paginatedNotes = []
    // for (let i = page; i < page + PAGE_SIZE; i++) {
    //     if (i >= notes.length)
    //         break;
    //     paginatedNotes.push(notes[i]);
    // }
    console.log(notes.length)
    response.body = notes
    response.status = 200; // ok
});

router.get('/:language/:p/', async (ctx) => {
    const response = ctx.response;
    const userId = ctx.state.user._id;
    const page = Number(ctx.params.p);
    const language = ctx.params.language;
    if (page == 0) {
        response.body = await noteStore.find({userId, language: language})
    } else {
        console.log('ye')
        const notes = await noteStore.find({userId: userId, language: language});
        console.log(notes)
        const paginatedNotes = []
        for (let i = page; i < page + PAGE_SIZE; i++) {
            if (i >= notes.length)
                break;
            paginatedNotes.push(notes[i]);
        }
        response.body = paginatedNotes
    }
    response.status = 200; // ok
});

const createNote = async (ctx, note, response) => {
    try {
        const userId = ctx.state.user._id;
        note.userId = userId;
        console.log(note)
        response.body = await noteStore.insert(note);
        response.status = 201; // created
        broadcast(userId, {type: 'created', payload: response.body});
    } catch (err) {
        response.body = {message: err.message};
        response.status = 400; // bad request
    }
};

router.post('/', async ctx => await createNote(ctx, ctx.request.body, ctx.response));

router.put('/:id', async (ctx) => {
    const note = ctx.request.body;
    const id = ctx.params.id;
    const noteId = note._id;
    const response = ctx.response;

    console.log('note ', note)
    console.log('id ', id)
    console.log('note id ', noteId)
    if (noteId && noteId != id) {
        response.body = {message: 'Param id and body _id should be the same'};
        response.status = 400; // bad request
        return;
    }
    if (!noteId) {
        await createNote(ctx, note, response);
    } else {
        const userId = ctx.state.user._id;
        note.userId = userId;
        const updatedCount = await noteStore.update({_id: id}, note);
        console.log('uu ', updatedCount)
        if (updatedCount == 1) {
            response.body = note;
            response.status = 200; // ok
            broadcast(userId, {type: 'updated', payload: note});
        } else {
            response.body = {message: 'Resource no longer exists'};
            response.status = 405; // method not allowed
        }
    }
});

router.del('/:id', async (ctx) => {
    const userId = ctx.state.user._id;
    const note = await noteStore.findOne({_id: ctx.params.id});
    if (note && userId !== note.userId) {
        ctx.response.status = 403; // forbidden
    } else {
        await noteStore.remove({_id: ctx.params.id});
        ctx.response.status = 204; // no content
    }
});
