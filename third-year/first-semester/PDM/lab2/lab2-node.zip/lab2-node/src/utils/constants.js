export const jwtConfig = { secret: 'my-secret' };
