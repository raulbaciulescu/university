package com.example.mymovieapp.todo.data.remote

import com.example.mymovieapp.todo.data.Item


data class ItemEvent(val type: String, val payload: Item)
