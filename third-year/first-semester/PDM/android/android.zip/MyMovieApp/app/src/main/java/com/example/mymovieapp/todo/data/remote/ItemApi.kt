package com.example.mymovieapp.todo.data.remote

import com.example.mymovieapp.todo.data.Item
import com.example.mymovieapp.todo.data.ItemOffline
import retrofit2.http.*

interface ItemApi {
    @GET("/api/item")
    suspend fun find(): List<Item>

    @GET("/api/item/{id}")
    suspend fun read(@Path("id") itemId: String?): Item;

    @Headers("Content-Type: application/json")
    @POST("/api/item")
    suspend fun create(@Body item: Item): Item

    @Headers("Content-Type: application/json")
    @PUT("/api/item/{id}")
    suspend fun update(@Path("id") itemId: String?, @Body item: Item): Item
}
