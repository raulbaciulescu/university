package com.example.mymovieapp.todo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "itemsOffline")
data class ItemOffline(@PrimaryKey val _id: String = "", val name: String = "", val manager: String = "", val year: String = "")