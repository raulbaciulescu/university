package com.example.mymovieapp.todo.ui.services.network

import android.app.Application
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.mymovieapp.todo.ui.services.notification.createNotificationChannel
import com.example.mymovieapp.todo.ui.services.notification.showSimpleNotification
import kotlinx.coroutines.runBlocking


@Composable
fun NetworkStatus() {
    val context = LocalContext.current
    val channelId = "MyTestChannel"
    val notificationId = 0

    val myNetworkStatusViewModel = viewModel<NetworkStatusViewModel>(
        factory = NetworkStatusViewModel.Factory(
            LocalContext.current.applicationContext as Application
        )
    )

    LaunchedEffect(Unit) {
        createNotificationChannel(channelId, context)
    }

    LaunchedEffect(key1 = myNetworkStatusViewModel.uiState) {
        if (!myNetworkStatusViewModel.uiState)
            showSimpleNotification(
                context,
                channelId,
                notificationId,
                "Network status",
                "You don't have internet connection!"
            )
    }

    Text(
        "Is online: ${myNetworkStatusViewModel.uiState}"
    )
}
