package com.example.mymovieapp.todo.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.mymovieapp.todo.data.Item
import com.example.mymovieapp.todo.data.ItemOffline
import kotlinx.coroutines.flow.Flow

@Dao
interface ItemOfflineDao {
    @Query("SELECT * FROM ItemsOffline")
    fun getAll(): List<ItemOffline>

    @Query("SELECT * FROM ItemsOffline WHERE _id = :id")
    fun findById(id: String): Flow<List<ItemOffline>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(itemOffline: ItemOffline)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(items: List<ItemOffline>)

    @Update
    suspend fun update(item: ItemOffline): Int

    @Query("DELETE FROM ItemsOffline WHERE _id = :id")
    suspend fun deleteById(id: String): Int

    @Query("DELETE FROM ItemsOffline")
    suspend fun deleteAll()
}
