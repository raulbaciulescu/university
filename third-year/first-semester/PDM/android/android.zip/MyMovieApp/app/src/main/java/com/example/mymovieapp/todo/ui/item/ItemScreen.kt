package com.example.mymovieapp.todo.ui.item

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.mymovieapp.R
import com.example.mymovieapp.todo.data.Item
import com.example.mymovieapp.todo.ui.services.map.MyMap

@Composable
fun ItemScreen(itemId: String?, onClose: () -> Unit) {
    val itemViewModel = viewModel<ItemViewModel>(factory = ItemViewModel.Factory(itemId))
    val itemUiState = itemViewModel.uiState
    Log.d("ItemScreen", "itemUiState itemUiState = ${itemUiState.item}");
    var name by rememberSaveable { mutableStateOf(itemUiState.item?.name ?: "") }
    var manager by rememberSaveable { mutableStateOf(itemUiState.item?.manager ?: "") }
    var year by rememberSaveable { mutableStateOf(itemUiState.item?.year ?: "") }
    var lat: Double by rememberSaveable { mutableStateOf(itemUiState.item?.lat ?: 0.0) }
    var lng: Double by rememberSaveable { mutableStateOf(itemUiState.item?.lng ?: 0.0) }
    Log.d("ItemScreen", "recompose, text = $name, $manager, $year")

    LaunchedEffect(itemUiState.savingCompleted) {
        Log.d("ItemScreen", "Saving completed = ${itemUiState.savingCompleted}");
        if (itemUiState.savingCompleted) {
            onClose();
        }
    }

    var textInitialized by remember { mutableStateOf(itemId == null) }
    LaunchedEffect(itemId, itemUiState.isLoading) {
        Log.d("ItemScreen", "Saving completed = ${itemUiState.savingCompleted}");
        if (textInitialized) {
            return@LaunchedEffect
        }
        if (itemUiState.item != null && !itemUiState.isLoading) {
            name = itemUiState.item.name
            manager = itemUiState.item.manager
            year = itemUiState.item.year
            textInitialized = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = stringResource(id = R.string.item)) },
                actions = {
                    Button(onClick = {
                        Log.d("ItemScreen", "save item text = $name");
                        itemViewModel.saveOrUpdateItem(
                            Item(
                                name = name,
                                manager = manager,
                                year = year,
                                lat = lat,
                                lng = lng
                            )
                        )
                    }) { Text("Save") }
                }
            )
        }
    ) {
        if (itemUiState.isLoading) {
            CircularProgressIndicator()
            return@Scaffold
        }
        if (itemUiState.loadingError != null) {
            Text(text = "Failed to load item - ${itemUiState.loadingError.message}")
        }
        Column(
            modifier = Modifier
                .padding(24.dp)
        ) {
            TextField(
                value = name,
                onValueChange = { name = it }, label = { Text("Name") },
                modifier = Modifier.fillMaxWidth()
            )
            TextField(
                value = manager,
                onValueChange = { manager = it }, label = { Text("Manager") },
                modifier = Modifier.fillMaxWidth()
            )

            TextField(
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                value = year,
                onValueChange = { year = it }, label = { Text("Year") },
                modifier = Modifier.fillMaxWidth()
            )
            MyMap(
                lat = lat,
                long = lng,
                onMapClick = {x, y ->
                    lat = x
                    lng = y
                }
            )
        }
    }
}


@Preview
@Composable
fun PreviewItemScreen() {
    ItemScreen(itemId = "0", onClose = {})
}
