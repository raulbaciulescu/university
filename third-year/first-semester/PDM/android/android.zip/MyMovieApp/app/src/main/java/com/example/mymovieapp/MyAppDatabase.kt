package com.example.mymovieapp

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.mymovieapp.todo.data.Item
import com.example.mymovieapp.todo.data.ItemOffline
import com.example.mymovieapp.todo.data.local.ItemDao
import com.example.mymovieapp.todo.data.local.ItemOfflineDao

@Database(entities = arrayOf(Item::class, ItemOffline::class), version = 1)
abstract class MyAppDatabase : RoomDatabase() {
    abstract fun itemDao(): ItemDao
    abstract fun itemOfflineDao(): ItemOfflineDao

    companion object {
        @Volatile
        private var INSTANCE: MyAppDatabase? = null

        fun getDatabase(context: Context): MyAppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context,
                    MyAppDatabase::class.java,
                    "movieapp_database2"
                ) .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}