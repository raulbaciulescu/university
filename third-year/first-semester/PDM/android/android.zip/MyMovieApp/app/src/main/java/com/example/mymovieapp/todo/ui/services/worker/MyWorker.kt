package com.example.mymovieapp.todo.ui.services.worker

import android.content.Context
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.mymovieapp.MyAppDatabase
import com.example.mymovieapp.core.data.Api
import com.example.mymovieapp.core.data.TAG
import com.example.mymovieapp.todo.data.Item
import com.example.mymovieapp.todo.data.remote.ItemApi
import com.example.mymovieapp.todo.ui.services.network.MyNetwork
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.runBlocking

class MyWorker(
    private val context: Context,
    private val workerParams: WorkerParameters
) : Worker(context, workerParams) {
    private val itemOfflineDao = MyAppDatabase.getDatabase(context = context).itemOfflineDao()
    private val itemDao = MyAppDatabase.getDatabase(context = context).itemDao()
    private val itemApi: ItemApi = Api.retrofit.create(ItemApi::class.java)
    private val myNetwork: MyNetwork by lazy { MyNetwork(context) }

    override fun doWork(): Result {
        Log.d("MyWorker", "begin")
        var retry: Boolean = false
        var i = Item()
        if (myNetwork.isNetworkAvailable()) {
            runBlocking {
                try {
                    val items = itemOfflineDao.getAll()
                    Log.d("MyWorker", "items size: " + items.size + " " + items[0]._id + " " + items[0].name)
                    if (items.isEmpty())
                            retry = true
                    items.forEach { item ->
                        run {
                            i = itemApi.create(Item(_id = "", name = item.name,
                                manager = item.manager, year = item.year))
                            Log.d("MyWorker", "created: " + i.name + " " + i._id)
                        }
                    }
                    itemDao.insert(i)
                    itemOfflineDao.deleteAll()
                    itemDao.deleteById("x")
                    Log.d("MyWorker", "deleted")
                } catch (e: Exception) {
                    Log.d("MyWorker", "e: " + e.message)
                    retry = true
                }
            }
            Log.d("MyWorker", "end")
            return if (retry)
                Result.retry()
            else
                Result.success()
        }
        else
            return Result.retry()
    }
}