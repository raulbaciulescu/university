package com.example.mymovieapp

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import com.example.mymovieapp.auth.data.AuthRepository
import com.example.mymovieapp.auth.data.remote.AuthDataSource
import com.example.mymovieapp.core.data.Api
import com.example.mymovieapp.core.data.UserPreferencesRepository
import com.example.mymovieapp.todo.data.ItemRepository
import com.example.mymovieapp.todo.data.remote.ItemApi
import com.example.mymovieapp.todo.data.remote.ItemWsClient
import com.example.mymovieapp.todo.ui.services.network.MyNetwork

val Context.userPreferencesDataStore by preferencesDataStore(
    name = "user_preferences"
)

class AppContainer(private val context: Context) {
    private val itemApi: ItemApi = Api.retrofit.create(ItemApi::class.java)
    private val itemWsClient: ItemWsClient = ItemWsClient(Api.okHttpClient)
    private val authDataSource: AuthDataSource = AuthDataSource()
    private val database: MyAppDatabase by lazy { MyAppDatabase.getDatabase(context) }
    private val myNetwork: MyNetwork by lazy { MyNetwork(context) }

    val itemRepository: ItemRepository by lazy {
        ItemRepository(itemApi, itemWsClient, database.itemDao(),database.itemOfflineDao(), myNetwork)
    }

    val authRepository: AuthRepository by lazy {
        AuthRepository(authDataSource)
    }

    val userPreferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(context.userPreferencesDataStore)
    }
}
