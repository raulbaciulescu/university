package com.example.mymovieapp.todo.data

import android.util.Log
import com.example.mymovieapp.core.data.TAG
import com.example.mymovieapp.todo.data.local.ItemDao
import com.example.mymovieapp.todo.data.local.ItemOfflineDao
import com.example.mymovieapp.todo.data.remote.ItemEvent
import com.example.mymovieapp.todo.data.remote.ItemApi
import com.example.mymovieapp.todo.data.remote.ItemWsClient
import com.example.mymovieapp.todo.ui.services.network.MyNetwork
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext

class ItemRepository(
    private val itemApi: ItemApi,
    private val itemWsClient: ItemWsClient,
    private val itemDao: ItemDao,
    private val itemOfflineDao: ItemOfflineDao,
    private val myNetwork: MyNetwork
) {
    val itemStream by lazy { itemDao.getAll() }

    suspend fun refresh() {
        Log.d(TAG, "refresh started")
        try {
            val items = itemApi.find()
            itemDao.deleteAll()
            items.forEach { itemDao.insert(it) }
            Log.d(TAG, "refresh succeeded")
        } catch (e: Exception) {
            Log.w(TAG, "refresh failed", e)
        }
    }

    suspend fun openWsClient() {
        Log.d(TAG, "openWsClient")
        withContext(Dispatchers.IO) {
            getItemEvents().collect {
                Log.d(TAG, "Item event collected $it")
                if (it.isSuccess) {
                    val itemEvent = it.getOrNull();
                    when (itemEvent?.type) {
//                          "created" -> handleItemCreated(itemEvent.payload)
                        //  "updated" -> handleItemUpdated(itemEvent.payload)
                        //  "deleted" -> handleItemDeleted(itemEvent.payload)
                    }
                }
            }
        }
    }

    suspend fun closeWsClient() {
        Log.d(TAG, "closeWsClient")
        withContext(Dispatchers.IO) {
            itemWsClient.closeSocket()
        }
    }

    private suspend fun getItemEvents(): Flow<Result<ItemEvent>> = callbackFlow {
        Log.d(TAG, "getItemEvents started")
        itemWsClient.openSocket(
            onEvent = {
                Log.d(TAG, "onEvent $it")
                if (it != null) {
                    trySend(Result.success(it))
                }
            },
            onClosed = { close() },
            onFailure = { close() });
        awaitClose { itemWsClient.closeSocket() }
    }

    suspend fun update(item: Item): Item {
        Log.d(TAG, "update $item...")
        val updatedItem = itemApi.update(item._id, item)
        Log.d(TAG, "update $item succeeded")
        handleItemUpdated(updatedItem)
        return updatedItem
    }

    suspend fun save(item: Item): Item {
        return if (myNetwork.isNetworkAvailable()) {
            Log.d(TAG, "save $item...")
            Log.d(TAG, "internet!")
            val createdItem = itemApi.create(item)
            Log.d(TAG, "save $createdItem succeeded")
            handleItemCreated(createdItem)
            createdItem
        } else {
            Log.d(TAG, "fara internet")
            val offlineItem = ItemOffline(_id = "", name = item.name, manager = item.manager, year = item.year)
            itemOfflineDao.insert(offlineItem)
            itemDao.insert(item.copy(_id = "x"))
            Log.d(TAG, "save offline $offlineItem succeeded")
            item
        }
    }

    private suspend fun handleItemUpdated(item: Item) {
        Log.d(TAG, "handleItemUpdated...")
        itemDao.update(item)
    }

    private suspend fun handleItemCreated(item: Item) {
        Log.d(TAG, "handleItemCreated... $item")
        itemDao.insert(item)
    }

    suspend fun deleteAll() {
        itemDao.deleteAll()
    }

    fun setToken(token: String) {
        itemWsClient.authorize(token)
    }
}