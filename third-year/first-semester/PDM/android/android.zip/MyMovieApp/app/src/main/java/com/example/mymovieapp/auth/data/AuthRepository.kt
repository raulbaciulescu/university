package com.example.mymovieapp.auth.data

import android.util.Log
import com.example.mymovieapp.auth.data.remote.AuthDataSource
import com.example.mymovieapp.auth.data.remote.TokenHolder
import com.example.mymovieapp.auth.data.remote.User
import com.example.mymovieapp.core.data.Api
import com.example.mymovieapp.core.data.TAG

class AuthRepository(private val authDataSource: AuthDataSource) {
    init {
        Log.d(TAG, "init")
    }

    fun clearToken() {
        Api.tokenInterceptor.token = null
    }

    suspend fun login(username: String, password: String): Result<TokenHolder> {
        val user = User(username, password)
        val result = authDataSource.login(user)
        if (result.isSuccess) {
            Api.tokenInterceptor.token = result.getOrNull()?.token
        }
        return result
    }
}
