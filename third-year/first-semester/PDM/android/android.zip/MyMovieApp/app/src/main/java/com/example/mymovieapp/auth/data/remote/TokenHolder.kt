package com.example.mymovieapp.auth.data.remote

data class TokenHolder(
    val token: String
)
