package com.example.mymovieapp.core.data

data class UserPreferences(val username: String = "", val token: String = "")
