package com.example.mymovieapp.todo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "items")
data class Item(@PrimaryKey val _id: String = "", val name: String = "", val manager: String = "", val year: String = "",
                val lat: Double = 18.414472095445163,
                val lng: Double = 10.800405107438564
)