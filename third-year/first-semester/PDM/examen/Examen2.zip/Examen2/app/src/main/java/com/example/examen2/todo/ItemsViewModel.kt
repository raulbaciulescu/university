package com.example.examen2.todo

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.examen2.MyApplication
import com.example.examen2.auth.TAG
import com.example.examen2.todo.answers.Answer
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking


data class ItemsUiState(
    val questionsNumber: Int = 0,
    val currentQuestion: Int = 0,
    val correctQuestions: Int = 0,
    val answeredQuestions: Int = 0,
    val items: List<Item> = mutableListOf()
)


sealed interface ItemsUiStateInterface {
    data class Success(val items: List<Item>) : ItemsUiStateInterface
    data class Error(val exception: Throwable?) : ItemsUiStateInterface
    object Loading : ItemsUiStateInterface
}

class ItemsViewModel(private val itemRepository: ItemRepository) : ViewModel() {
    var uiState: ItemsUiState by mutableStateOf(ItemsUiState())
        private set
    var uiStateInterface: ItemsUiStateInterface by mutableStateOf(ItemsUiStateInterface.Loading)
        private set


    init {
        Log.d(TAG, "init")
        loadItems()
    }

    private fun loadItems() {
        Log.d(TAG, "loadItems...")
        viewModelScope.launch {
            itemRepository.itemStream.collect {
                Log.d(TAG, "load... $it")
                uiState = uiState.copy(items = it, questionsNumber = it.size)
                uiStateInterface = ItemsUiStateInterface.Success(it)
            }
        }
    }

    fun onNextClick(selectedOption: String) {
        Log.d("items view model", selectedOption)
        val item: Item = uiState.items[uiState.currentQuestion]
        Log.d(TAG, "$item")
        Log.d(TAG, "${item.options[item.indexCorrectOption]} vs $selectedOption")
        if (item.options[item.indexCorrectOption] == selectedOption) {
            Log.d(TAG, "correct")
            uiState = uiState.copy(correctQuestions = uiState.correctQuestions + 1)
        }
        runBlocking {
            itemRepository.saveAnswer(
                Answer(
                    text = selectedOption,
                    questionId = uiState.items[uiState.currentQuestion].id
                )
            )
        }
        uiState = uiState.copy(
            currentQuestion = if (uiState.currentQuestion < uiState.questionsNumber) uiState.currentQuestion + 1 else uiState.currentQuestion,
            answeredQuestions = uiState.answeredQuestions + 1
        )
    }

    fun onNextWithoutClick() {
        Log.d(TAG, "on next without click")
        uiState = uiState.copy(
            currentQuestion = if (uiState.currentQuestion < uiState.questionsNumber) uiState.currentQuestion + 1 else uiState.currentQuestion,
            answeredQuestions = uiState.answeredQuestions + 1
        )
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app =
                    (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as MyApplication)
                ItemsViewModel(app.container.itemRepository)
            }
        }
    }
}
