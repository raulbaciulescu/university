package com.example.examen2.auth.data.remote

data class LoginRequest(
    val id: String,
)
