package com.example.examen2.todo

import retrofit2.http.*

interface ItemApi {
    @GET("/question/{id}")
    suspend fun findById(@Path("id") itemId: Int): Item
}
