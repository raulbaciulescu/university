package com.example.examen2.auth.data.remote

data class LoginResponse(
    val token: String,
    val questionIds: List<Int>
)
