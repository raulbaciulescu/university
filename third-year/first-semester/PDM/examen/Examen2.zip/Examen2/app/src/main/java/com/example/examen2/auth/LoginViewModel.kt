package com.example.examen2.auth

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.examen2.MyApplication
import com.example.examen2.UserPreferences
import com.example.examen2.UserPreferencesRepository
import com.example.examen2.auth.data.AuthRepository
import com.example.examen2.todo.Item
import com.example.examen2.todo.ItemDao
import com.example.examen2.todo.ItemRepository
import kotlinx.coroutines.launch

data class LoginUiState(
    val isAuthenticating: Boolean = false,
    val authenticationError: Throwable? = null,
    val authenticationCompleted: Boolean = false,
    val token: String = "",

    val questionNumber: Int = 0,
    val questionFetched: Int = 0,
    val shouldRetry: Boolean = false
)

class LoginViewModel(
    private val authRepository: AuthRepository,
    private val itemRepository: ItemRepository,
    private val itemDao: ItemDao,
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {
    var uiState: LoginUiState by mutableStateOf(LoginUiState())

    fun login(id: String) {
        viewModelScope.launch {
            Log.v(TAG, "login...");
            uiState = uiState.copy(isAuthenticating = true, authenticationError = null)
            val result = authRepository.login(id)
            if (result.isSuccess) {
                uiState = uiState.copy(questionNumber = result.getOrNull()?.questionIds?.size ?: 0)
                getQuestions(result.getOrNull()?.questionIds)

//                userPreferencesRepository.save(
//                    UserPreferences(
//                        result.getOrNull()?.token ?: ""
//                    )
//                )
                uiState = uiState.copy(isAuthenticating = false, authenticationCompleted = true)
            } else {
                uiState = uiState.copy(
                    isAuthenticating = false,
                    authenticationError = result.exceptionOrNull()
                )
            }
        }
    }

    private suspend fun getQuestions(questionIds: List<Int>?) {
        try {
            questionIds?.forEach { id ->
                val item: Item = itemRepository.getItem(id)
                Log.d(TAG, "get questions ${item}")
                itemDao.insert(item)
                uiState = uiState.copy(questionFetched = uiState.questionFetched + 1)
            }
        } catch (e: Exception) {
            Log.d("eedddd", "Exc")
            uiState = uiState.copy(shouldRetry = true)
        }

    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app =
                    (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as MyApplication)
                LoginViewModel(
                    app.container.authRepository,
                    app.container.itemRepository,
                    app.container.database.itemDao(),
                    app.container.userPreferencesRepository
                )
            }
        }
    }
}