package com.example.examen2.auth.data

import android.util.Log
import com.example.examen2.todo.Api
import com.example.examen2.auth.data.remote.AuthDataSource
import com.example.examen2.auth.data.remote.LoginRequest
import com.example.examen2.auth.data.remote.LoginResponse
import com.example.examen2.auth.data.remote.TAG

class AuthRepository(private val authDataSource: AuthDataSource) {
    init {
        Log.d(TAG, "init")
    }

    fun clearToken() {
        Api.tokenInterceptor.token = null
    }

    suspend fun login(id: String): Result<LoginResponse> {
        val loginRequest = LoginRequest(id)
        val result = authDataSource.login(loginRequest)
        if (result.isSuccess) {
            Api.tokenInterceptor.token = result.getOrNull()?.token
        }
        return result
    }
}
