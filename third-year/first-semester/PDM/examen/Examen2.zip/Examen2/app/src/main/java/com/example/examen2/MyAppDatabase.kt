package com.example.examen2

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.examen2.todo.Item
import com.example.examen2.todo.ItemDao
import com.example.examen2.todo.ListTypeConverter
import com.example.examen2.todo.answers.Answer
import com.example.examen2.todo.answers.AnswerDao

@Database(entities = arrayOf(Item::class, Answer::class), version = 1)
@TypeConverters(ListTypeConverter::class)
abstract class MyAppDatabase : RoomDatabase() {
    abstract fun itemDao(): ItemDao
    abstract fun answerDao(): AnswerDao

    companion object {
        @Volatile
        private var INSTANCE: MyAppDatabase? = null

        fun getDatabase(context: Context): MyAppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context,
                    MyAppDatabase::class.java,
                    "exam2_db3"
                ) .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}