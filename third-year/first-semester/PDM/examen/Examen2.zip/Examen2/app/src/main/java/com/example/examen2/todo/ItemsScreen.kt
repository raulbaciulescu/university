package com.example.examen2.todo

import kotlinx.coroutines.delay
import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.*
import androidx.compose.material.CheckboxDefaults.colors
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

@Composable
fun ItemsScreen() {
    Log.d("ItemsScreen", "recompose")
    val itemsViewModel = viewModel<ItemsViewModel>(factory = ItemsViewModel.Factory)
    val itemsUiState = itemsViewModel.uiState
    val uiStateInterface = itemsViewModel.uiStateInterface
    val selectedOption = remember { mutableStateOf("") }

    LaunchedEffect(CoroutineScope(Dispatchers.Main)) {
        delay(5000)
        itemsViewModel.onNextWithoutClick()
    }

//    LaunchedEffect(Unit) {
//        while(true) {
//            delay(5000)
//            itemsViewModel.onNextWithoutClick()
//        }
//    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(text = "Question ${itemsUiState.currentQuestion} / ${itemsUiState.questionsNumber}")
                },
                actions = {
                    Text(text = "Correct Questions ${itemsUiState.correctQuestions} / ${itemsUiState.answeredQuestions}")
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    Log.d("ItemsScreen", "next: $selectedOption")
                    itemsViewModel.onNextClick(selectedOption.value)
                },
            ) { Icon(Icons.Rounded.ArrowForward, "Next") }
        }
    ) {
        when (uiStateInterface) {
            is ItemsUiStateInterface.Success -> {
                Column {
                    Text(text = uiStateInterface.items[itemsUiState.currentQuestion].text)
                    uiStateInterface.items[itemsUiState.currentQuestion].options.forEach {
                        Row(
                            Modifier.padding(horizontal = 16.dp)
                        ) {
                            RadioButton(
                                selected = selectedOption.value == it,
                                onClick = { selectedOption.value = it },
                            )
                            Text(text = it)
                        }
                    }
                }
            }
            is ItemsUiStateInterface.Loading -> CircularProgressIndicator()
            is ItemsUiStateInterface.Error -> Text(text = "Failed to load items")
        }
    }
}