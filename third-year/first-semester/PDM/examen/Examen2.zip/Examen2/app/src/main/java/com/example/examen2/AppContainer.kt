package com.example.examen2
import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import com.example.examen2.auth.data.AuthRepository
import com.example.examen2.auth.data.remote.AuthDataSource
import com.example.examen2.todo.Api
import com.example.examen2.todo.ItemApi
import com.example.examen2.todo.ItemRepository
import com.example.examen2.todo.ItemWsClient

val Context.userPreferencesDataStore by preferencesDataStore(
    name = "user_preferences"
)

class AppContainer(private val context: Context) {
    private val itemApi: ItemApi = Api.retrofit.create(ItemApi::class.java)
    private val itemWsClient: ItemWsClient = ItemWsClient(Api.okHttpClient)
    private val authDataSource: AuthDataSource = AuthDataSource()
    val database: MyAppDatabase by lazy { MyAppDatabase.getDatabase(context) }

    val itemRepository: ItemRepository by lazy {
        ItemRepository(itemApi, database.itemDao(), database.answerDao(), itemWsClient)
    }

    val authRepository: AuthRepository by lazy {
        AuthRepository(authDataSource)
    }

    val userPreferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(context.userPreferencesDataStore)
    }
}
