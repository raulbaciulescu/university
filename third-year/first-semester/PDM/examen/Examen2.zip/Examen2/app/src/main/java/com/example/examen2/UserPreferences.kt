package com.example.examen2

data class UserPreferences(val token: String = "")
