package com.example.examen2.auth.data.remote

import com.example.examen2.todo.Api
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

class AuthDataSource() {
    interface AuthService {
        @Headers("Content-Type: application/json")
        @POST("/auth")
        suspend fun login(@Body loginRequest: LoginRequest): LoginResponse
    }

    private val authService: AuthService = Api.retrofit.create(AuthService::class.java)

    suspend fun login(loginRequest: LoginRequest): Result<LoginResponse> {
        return try {
            Result.success(authService.login(loginRequest))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

