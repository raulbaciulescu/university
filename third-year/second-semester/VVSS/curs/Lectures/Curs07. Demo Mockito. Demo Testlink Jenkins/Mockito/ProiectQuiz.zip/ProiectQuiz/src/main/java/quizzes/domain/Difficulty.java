package quizzes.domain;

public enum Difficulty {
    Easy, Medium, Hard, None
}