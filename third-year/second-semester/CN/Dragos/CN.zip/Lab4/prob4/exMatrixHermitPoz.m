function A = exMatrixHermitPoz ()

  A = [ 5.5737   1.0593   1.2728 ; 1.0593   4.1293   1.3206 ; 1.2728   1.3206   4.7684 ]

end
