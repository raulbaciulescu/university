function x = P3 ()

  A = [ 1 1 1; 1 1 0; 0 1 1; 1 0 0; 0 0 1];
  b = [89; 67; 53; 35; 20];

  x  = A \ b;

endfunction
