
disp("Modelul eliptic:");
modelEliptic()
disp("----------------------------");
disp("Modelul parabolic:");
modelParabolic();
disp("----------------------------");
disp("Rezultat: modelul eliptic este mai probabil deoarece are eroarea mai mica");