function P1 ()

  x = [3.8, 4.2, 5];
  X = [3 4 5];
  Y = [7 6 5];

  y = lagrange1(x,X,Y)
endfunction
