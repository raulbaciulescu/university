function P5_test ()
  
  printf("Pentru eroarea 1e-10 :");
  [my_e,n] = prob5(1e-10);
  printf("n este: %d",n);
  printf("\npentru e: "); my_e
  
 # printf("\neps :"); disp(e);

endfunction
