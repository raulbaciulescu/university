function P1 ()

  A = [ 3 0 1 ; 0 2 0 ; 0 0 1 ];
  b = [ 7.5 ; 4 ; 3 ];

  expected = [ 1.5 ; 2 ; 3 ]
  actual = jacobi(A,b)

end
