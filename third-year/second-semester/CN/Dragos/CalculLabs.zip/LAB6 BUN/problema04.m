LagrangeV2(1.2, @exp, 3, [1.1 1.4 1.6])
exp(1.2)