LagrangeBari([1 1.5 2], [exp(1) exp(1.5) exp(2)], 1.2)
exp(1.2)