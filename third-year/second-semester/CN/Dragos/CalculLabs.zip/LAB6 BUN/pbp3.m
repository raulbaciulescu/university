LagrangeV2(115, @sqrt, 4, [113 114 116 117]) % ultimele sunt nodurile
sqrt(115)