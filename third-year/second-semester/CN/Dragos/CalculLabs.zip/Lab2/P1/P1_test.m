
function retval = P1_test ()
  fprintf("Epsilonul masinii: "); myeps()
  fprintf("\nRealmin: "); myRealmin()
  fprintf("\nRealmax: "); myRealmax() 
  
end

