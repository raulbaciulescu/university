
function [] = P4_test ()
  warning('off','all');

  fprintf("Reprezentarea binara pe componente a numarului 1 este :\n-> ");
  f2b(1)
  fprintf("Reprezentarea binara pe componente a numarului -0.453125 este: \n-> ");
  f2b(-0.453125)
end
