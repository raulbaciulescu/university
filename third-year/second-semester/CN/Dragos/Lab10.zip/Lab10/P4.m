%f = @(x) 1/x;
f = @(x) sin(x);
e = 0.01;

Romberg(f,1,2,4,e)